using UnityEngine;
using UnityEngine.UIElements;
using System;

namespace MyInventory
{
    public class ItemDragManipulator : PointerManipulator
    {
        private readonly VisualElement _screenRoot;
        private readonly int _srcIndex;
        private readonly Func<bool> _hasItemCheck;
        private readonly Action<int, int> _onDropRequest;
        private readonly Action<int> _onDeleteRequest;

        private bool _isDragging;
        private VisualElement _ghostIcon;

        // [복구 완료] 분할 팝업을 띄우기 위한 이벤트 채널
        public event Action<int, int> OnSplitDropRequest;

        public ItemDragManipulator(VisualElement screenRoot, int srcIndex, Func<bool> hasItemCheck, 
                                   Action<int, int> onDropRequest, Action<int> onDeleteRequest)
        {
            _screenRoot = screenRoot;
            _srcIndex = srcIndex;
            _hasItemCheck = hasItemCheck;
            _onDropRequest = onDropRequest;
            _onDeleteRequest = onDeleteRequest;
            _isDragging = false;
        }

        protected override void RegisterCallbacksOnTarget()
        {
            target.RegisterCallback<PointerDownEvent>(OnPointerDown);
            target.RegisterCallback<PointerMoveEvent>(OnPointerMove);
            target.RegisterCallback<PointerUpEvent>(OnPointerUp);
        }

        protected override void UnregisterCallbacksFromTarget()
        {
            target.UnregisterCallback<PointerDownEvent>(OnPointerDown);
            target.UnregisterCallback<PointerMoveEvent>(OnPointerMove);
            target.UnregisterCallback<PointerUpEvent>(OnPointerUp);
        }

        private void OnPointerDown(PointerDownEvent evt)
        {
            if (_hasItemCheck == null || !_hasItemCheck() || evt.button != 0) return;

            _isDragging = true;
            target.CapturePointer(evt.pointerId);

            VisualElement originalIcon = target.Q<VisualElement>("Item-Icon");
            _ghostIcon = new VisualElement();
            
            float width = target.layout.width > 0 ? target.layout.width : 100f;
            float height = target.layout.height > 0 ? target.layout.height : 100f;
            _ghostIcon.style.width = width;
            _ghostIcon.style.height = height;

            if (originalIcon != null && originalIcon.style.backgroundImage.value.sprite != null)
            {
                _ghostIcon.style.backgroundImage = originalIcon.style.backgroundImage;
                _ghostIcon.style.unityBackgroundImageTintColor = Color.white;
            }

            _ghostIcon.style.position = Position.Absolute;
            _ghostIcon.style.opacity = 0.6f;
            _ghostIcon.pickingMode = PickingMode.Ignore;

            _screenRoot.Add(_ghostIcon);
            UpdateGhostPosition(evt.position);

            evt.StopPropagation();
        }

        private void OnPointerMove(PointerMoveEvent evt)
        {
            if (!_isDragging || _ghostIcon == null) return;

            UpdateGhostPosition(evt.position);
            evt.StopPropagation();
        }

        private void OnPointerUp(PointerUpEvent evt)
        {
            if (!_isDragging) return;

            _isDragging = false;
            target.ReleasePointer(evt.pointerId);

            if (_ghostIcon != null)
            {
                _ghostIcon.RemoveFromHierarchy();
                _ghostIcon = null;
            }

            VisualElement pickedElement = _screenRoot.panel.Pick(evt.position);
            
            if (pickedElement == null)
            {
                _onDeleteRequest?.Invoke(_srcIndex);
                return;
            }

            VisualElement targetSlot = FindParentSlot(pickedElement);
            if (targetSlot != null && targetSlot.userData is int destIndex)
            {
                // [복구 완료] Shift 키를 누르고 드롭했는지 판별하여 분할 요청 발송
                if (Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift))
                {
                    OnSplitDropRequest?.Invoke(_srcIndex, destIndex);
                }
                else
                {
                    _onDropRequest?.Invoke(_srcIndex, destIndex);
                }
                return;
            }

            if (IsInsideInventoryWindow(pickedElement))
            {
                return;
            }

            _onDeleteRequest?.Invoke(_srcIndex);
            evt.StopPropagation();
        }

        private void UpdateGhostPosition(Vector2 panelPosition)
        {
            if (_ghostIcon == null) return;
            
            float width = _ghostIcon.style.width.value.value;
            float height = _ghostIcon.style.height.value.value;

            _ghostIcon.style.left = panelPosition.x - (width / 2f);
            _ghostIcon.style.top = panelPosition.y - (height / 2f);
        }

        private VisualElement FindParentSlot(VisualElement element)
        {
            VisualElement current = element;
            while (current != null)
            {
                if (current.ClassListContains("slot-default") || current.userData is int)
                {
                    return current;
                }
                current = current.parent;
            }
            return null;
        }

        private bool IsInsideInventoryWindow(VisualElement element)
        {
            VisualElement current = element;
            while (current != null)
            {
                if (current.name == "Inventory")
                {
                    return true;
                }
                current = current.parent;
            }
            return false;
        }
    }
}