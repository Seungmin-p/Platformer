using System;
using UnityEngine;

namespace MyInventory
{
    ///<summary> 수량을 셀 수 있는 아이템 (Model 계층) </summary>
    public abstract class CountableItem : Item
    {
        public CountableItemData CountableData { get; private set; }

        ///<summary> 현재 아이템 개수 </summary>
        public int Amount { get; protected set; }

        ///<summary> 하나의 슬롯이 가질 수 있는 최대 개수(기본 99) </summary>
        public int MaxAmount => CountableData.MaxAmount;

        ///<summary> 수량이 가득 찼는지 여부 </summary>
        public bool IsMax => Amount >= CountableData.MaxAmount;

        ///<summary> 개수가 없는지 여부 </summary>
        public bool IsEmpty => Amount <= 0;

        // --- MVVM 바인딩을 위한 모델 레이어의 이벤트 ---
        public event Action<int> OnAmountChanged;

        public CountableItem(CountableItemData data, int amount = 1) : base(data)
        {
            CountableData = data;
            SetAmount(amount);
        }

        ///<summary> 개수 지정(범위 제한) </summary>
        public void SetAmount(int amount)
        {
            int prevAmount = Amount;
            Amount = Mathf.Clamp(amount, 0, MaxAmount);

            //값이 실제로 변했을 때만 이벤트를 발생시켜 뷰모델에게 전파
            if (prevAmount != Amount)
            {
                OnAmountChanged?.Invoke(Amount);
            }
        }

        ///<summary> 개수 추가 및 최대치 초과량 반환(초과량 없을 경우 0) </summary>
        public int AddAmountAndGetExcess(int amount)
        {
            int nextAmount = Amount + amount;
            SetAmount(nextAmount);

            return (nextAmount > MaxAmount) ? (nextAmount - MaxAmount) : 0;
        }

        ///<summary> 개수를 나누어 복제 </summary>
        public CountableItem SeperateAndClone(int amount)
        {
            //수량이 한개 이하일 경우, 복제 불가
            if(Amount <= 1) return null;

            if(amount > Amount - 1)
                amount = Amount - 1;

            //[수정된 부분] 직접 차감 대신 SetAmount를 호출하여 이벤트가 정상적으로 발생하도록 유도
            SetAmount(Amount - amount); 
        
            return Clone(amount);
        }

        protected abstract CountableItem Clone(int amount);
    }
}