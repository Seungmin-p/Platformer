using System;
using System.Collections.Generic;
using UnityEngine;

namespace MyInventory
{
    //인벤토리 Model
    public class Inventory : MonoBehaviour
    {
        //초기 인벤 칸, 최대 칸
        [SerializeField, Range(8, 64)] int _initialCapacity = 32;
        [SerializeField, Range(8, 64)] int _maxCapacity = 64;

        //인벤토리 슬롯 배열 및 내부 인덱스 연산용 변수
        private Item[] _items;
        private readonly HashSet<int> _indexSetForUpdate = new HashSet<int>();
        
        //정렬처리용 변수
        private IComparer<Item> _itemComparer;

        //외부 전달용 인벤토리 크기 프로퍼티
        public int Capacity { get; private set; }

        //MVVM 구조를 위한 이벤트
        public event Action<int> OnSlotUpdated; //슬롯 업데이트
        public event Action OnAllSlotsUpdated; //전체 슬롯 업데이트
        public event Action<int> OnCapacityChanged; //인벤토리 크기 업데이트

        //정렬을 위한 아이템 유형 별 가중치
        private readonly static Dictionary<Type, int> _sortWeightDict = new Dictionary<Type, int>
        {
            { typeof(WeaponItemData), 10000 },
            { typeof(ArmorItemData),  20000 }, 
            { typeof(PotionItemData),   30000 }, 
            { typeof(MaterialItemData),   40000 }, 
        };

        private void Awake()
        {
            //인벤토리 칸 수가 최대치를 넘을 수 없게 함
            if (_initialCapacity > _maxCapacity) _initialCapacity = _maxCapacity;
            
            //Array.Sort를 이용하기 위한 IComparer 규격의 객체를 미리 저장해둠
            _itemComparer = Comparer<Item>.Create(CompareItems);
            
            //최대치에 맞춰서 인벤토리 공간 확보 및 현재 칸 조정
            _items = new Item[_maxCapacity];
            Capacity = _initialCapacity;
        }

        private void Start()
        {
            //인벤토리 크기 할당을 위한 이벤트 호출
            OnCapacityChanged?.Invoke(Capacity);
        }

        // --- 가방 제어 핵심 비즈니스 로직 (Public Commands) ---
        public void Add(ItemData data, int amount)
        {
            int remaining = amount;

            if (data is CountableItemData)
            {
                for (int i = 0; i < Capacity; i++)
                {
                    if (_items[i] is CountableItem ci && ci.Data == data && !ci.IsMax)
                    {
                        remaining = ci.AddAmountAndGetExcess(remaining);
                        UpdateSlot(i);
                        if (remaining <= 0) return;
                    }
                }
            }

            if (remaining > 0)
            {
                for (int i = 0; i < Capacity; i++)
                {
                    if (_items[i] == null)
                    {
                        Item newItem = data.CreateItem();
                        _items[i] = newItem;

                        if (newItem is CountableItem ci)
                        {
                            ci.SetAmount(remaining);
                            remaining = 0;
                        }
                        else
                        {
                            remaining = 0;
                        }

                        UpdateSlot(i);
                        return;
                    }
                }
            }

            if (remaining > 0)
            {
                Debug.LogWarning($"[Inventory] 인벤토리가 가득 찼습니다! 남은 아이템 수량: {remaining}");
            }
        }

        public void Remove(int index)
        {
            if (!IsValidIndex(index)) return;
            _items[index] = null;
            UpdateSlot(index);
        }

        public void Swap(int indexA, int indexB)
        {
            if (!IsValidIndex(indexA) || !IsValidIndex(indexB)) return;

            Item itemA = _items[indexA];
            Item itemB = _items[indexB];

            if (itemA != null && itemB != null &&
                itemA.Data == itemB.Data &&
                itemA is CountableItem ciA && itemB is CountableItem ciB)
            {
                int maxAmount = ciB.MaxAmount;
                int sum = ciA.Amount + ciB.Amount;

                if (sum <= maxAmount)
                {
                    ciA.SetAmount(0);
                    ciB.SetAmount(sum);
                }
                else
                {
                    ciA.SetAmount(sum - maxAmount);
                    ciB.SetAmount(maxAmount);
                }
            }
            else
            {
                _items[indexA] = itemB;
                _items[indexB] = itemA;
            }
            UpdateSlot(indexA, indexB);
        }

        public void SeparateItem(int fromIndex, int toIndex, int amount)
        {
            if (fromIndex < 0 || fromIndex >= Capacity || toIndex < 0 || toIndex >= Capacity) return;
            if (_items[toIndex] != null) return; 

            if (_items[fromIndex] is CountableItem countableItem)
            {
                CountableItem separatedItem = countableItem.SeperateAndClone(amount);
                if (separatedItem != null)
                {
                    _items[toIndex] = separatedItem;
                    OnSlotUpdated?.Invoke(fromIndex);
                    OnSlotUpdated?.Invoke(toIndex);
                }
            }
        }

        public void Use(int index)
        {
            if (!IsValidIndex(index)) return;

            if (_items[index] is IUsableItem uItem)
            {
                if (uItem.Use()) UpdateSlot(index);
            }
        }

        public void TrimAll()
        {
            _indexSetForUpdate.Clear();

            int i = -1;
            while (i + 1 < Capacity && _items[++i] != null) ;
            int j = i;

            while (true)
            {
                while (++j < Capacity && _items[j] == null) ;
                if (j >= Capacity) break;

                _indexSetForUpdate.Add(i);
                _indexSetForUpdate.Add(j);

                _items[i] = _items[j];
                _items[j] = null;
                i++;
            }

            foreach (var index in _indexSetForUpdate) UpdateSlot(index);
        }

        public void SortAll()
        {
            MergeCountableItems();
            TrimAll(); 

            int i = 0;
            while (i < Capacity && _items[i] != null) i++;

            if (i > 1)
            {
                // [구조 수정 완료] 클래스 인스턴스 대신 정렬 비교 메서드를 직접 매개변수로 토스합니다.
                Array.Sort(_items, 0, i, _itemComparer);
                OnAllSlotsUpdated?.Invoke(); 
            }
        }

        // --- 내부 연산 보조용 프라이빗 헬퍼 함수 ---
        private bool IsValidIndex(int index) => index >= 0 && index < Capacity;

        /// <summary>
        /// [구조 수정 완료] 내부 클래스를 완전 폐지하고 인벤토리 클래스 소속으로 단량화된 정렬 판단 메서드입니다.
        /// </summary>
        private int CompareItems(Item a, Item b)
        {
            int weightA = a.Data.ID + _sortWeightDict[a.Data.GetType()];
            int weightB = b.Data.ID + _sortWeightDict[b.Data.GetType()];

            if (weightA != weightB) return weightA.CompareTo(weightB);

            if (a is CountableItem ciA && b is CountableItem ciB)
            {
                return ciB.Amount.CompareTo(ciA.Amount); 
            }
            return 0;
        }

        private void UpdateSlot(int index)
        {
            if (!IsValidIndex(index)) return;
            
            if (_items[index] is CountableItem ci && ci.IsEmpty)
            {
                _items[index] = null;
            }

            OnSlotUpdated?.Invoke(index);
        }

        private void UpdateSlot(params int[] indices)
        {
            foreach (var i in indices) UpdateSlot(i);
        }

        private void MergeCountableItems()
        {
            for (int i = 0; i < Capacity - 1; i++)
            {
                if (_items[i] is CountableItem targetItem)
                {
                    for (int j = i + 1; j < Capacity; j++)
                    {
                        if (targetItem.IsMax) break;

                        if (_items[j] is CountableItem sourceItem && targetItem.Data == sourceItem.Data)
                        {
                            int spaceLeft = targetItem.MaxAmount - targetItem.Amount;
                            int amountToMove = Mathf.Min(spaceLeft, sourceItem.Amount);

                            targetItem.SetAmount(targetItem.Amount + amountToMove);
                            sourceItem.SetAmount(sourceItem.Amount - amountToMove);

                            if (sourceItem.IsEmpty)
                            {
                                _items[j] = null;
                            }
                        }
                    }
                }
            }
        }
        
        //뷰 모델에서 호출할 데이터 조회용 메소드들
        //각각 해당 인덱스에 아이템이 존재하는지, 아이템이 무엇인지, 수량이 얼마나 되는지 확인
        public bool HasItem(int index) => IsValidIndex(index) && _items[index] != null;
        public Item GetItem(int index) => IsValidIndex(index) ? _items[index] : null;
        public int GetCurrentAmount(int index)
        {
            if (!IsValidIndex(index)) return -1;
            if (_items[index] == null) return 0;
            if (!(_items[index] is CountableItem ci)) return 1;
            return ci.Amount;
        }
    }
}