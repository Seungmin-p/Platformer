// MaterialItem.cs
namespace MyInventory
{
    /// <summary> 수량 아이템 - 소비가 불가능한 재료 (Model 계층) </summary>
    public class MaterialItem : CountableItem
    {
        public MaterialItem(MaterialItemData data, int amount = 1) : base(data, amount) { }

        protected override CountableItem Clone(int amount)
        {
            return new MaterialItem(CountableData as MaterialItemData, amount);
        }
    }
}