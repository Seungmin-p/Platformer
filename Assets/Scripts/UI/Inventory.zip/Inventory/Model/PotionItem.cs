namespace MyInventory
{
    /// <summary> 수량 아이템 - 포션 아이템 (Model 계층) </summary>
    public class PotionItem : CountableItem, IUsableItem
    {
        public PotionItem(PotionItemData data, int amount = 1) : base(data, amount) { }

        public bool Use()
        {
            // [방어 코드] 아이템이 이미 비어있다면 사용 처리를 취소하고 false를 반환합니다.
            if (IsEmpty) return false;

            // [수정된 부분] 직접 차감 대신 SetAmount를 호출하여 
            // 뷰모델과 UI 툴킷에 수량 변경 신호가 정상적으로 도달하도록 만듭니다.
            SetAmount(Amount - 1);

            // 소비 효과 적용 로직은 나중에 플레이어 스탯 시스템과 연동될 타겟팅 구조가 들어가면 좋습니다.
            // 예: Player.Instance.Heal(CountableData.Value);

            return true;
        }

        protected override CountableItem Clone(int amount)
        {
            // 부모의 CountableData를 원래의 데이터 타입으로 안전하게 캐스팅하여 복제 인스턴스 생성
            return new PotionItem(CountableData as PotionItemData, amount);
        }
    }
}