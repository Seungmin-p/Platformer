using UnityEngine;
using UnityEngine.UIElements;
using System.Collections.Generic;

namespace MyInventory
{
    [RequireComponent(typeof(UIDocument))]
    public class InventoryView : MonoBehaviour
    {
        [Header("UI Templates")] 
        [SerializeField] private VisualTreeAsset _slotTemplate;
        [SerializeField] private VisualTreeAsset _tooltipTemplate; 
        [SerializeField] private VisualTreeAsset _confirmationTemplate; 
        [SerializeField] private VisualTreeAsset _splitTemplate;        // [추가] 수량 분할 팝업 UXML 슬롯

        [Header("Grid Layout Automation")] 
        [SerializeField] private int _columnCount = 7;
        [SerializeField] private float _slotSize = 100f;
        [SerializeField] private float _slotHorizontalMargin = 6f;

        private InventoryViewModel _viewModel;
        private VisualElement _root;
        private VisualElement _inventoryWindow;
        private VisualElement _slotArea;

        private Button _btnClose;
        private Button _btnSort;
        private Button _btnTrim;

        private Button _btnFilterAll;
        private Button _btnFilterEquip;
        private Button _btnFilterConsume;
        private Button _btnFilterMaterial;

        // 독립형 오버레이 팝업 인스턴스
        private InventoryTooltipView _tooltipView;
        private InventoryConfirmationPopupView _confirmationPopupView; 
        private InventoryAmountSplitPopupView _amountSplitPopupView;    // [추가]

        private readonly List<ItemSlotView> _slotViews = new List<ItemSlotView>();

        private static readonly Color BtnNormalBgColor = new Color(0.18f, 0.18f, 0.18f, 1f);   
        private static readonly Color BtnActiveBgColor = new Color(0.26f, 0.26f, 0.26f, 1f);   
        private static readonly Color TxtWhiteColor = Color.white;
        private static readonly Color HighlightBorderColor = new Color(1f, 0.84f, 0f, 1f);   

        public void Bind(InventoryViewModel viewModel)
        {
            _viewModel = viewModel;
            _root = GetComponent<UIDocument>().rootVisualElement;

            _inventoryWindow = _root.Q<VisualElement>("Inventory");
            _slotArea = _root.Q<VisualElement>("Slot-Area");
            _btnClose = _root.Q<Button>("btn-close");
            _btnSort = _root.Q<Button>("btn-sort");
            _btnTrim = _root.Q<Button>("btn-trim");

            _btnFilterAll = _root.Q<Button>("btn-filter-all");
            _btnFilterEquip = _root.Q<Button>("btn-filter-equip");
            _btnFilterConsume = _root.Q<Button>("btn-filter-consume");
            _btnFilterMaterial = _root.Q<Button>("btn-filter-material");

            if (_btnClose != null) _btnClose.clicked += CloseWindow;
            if (_btnSort != null) _btnSort.clicked += _viewModel.CommandSort;
            if (_btnTrim != null) _btnTrim.clicked += _viewModel.CommandTrim;

            if (_btnFilterAll != null) _btnFilterAll.clicked += () => ApplyFilterVisual(ItemFilterType.All);
            if (_btnFilterEquip != null) _btnFilterEquip.clicked += () => ApplyFilterVisual(ItemFilterType.Equipment);
            if (_btnFilterConsume != null) _btnFilterConsume.clicked += () => ApplyFilterVisual(ItemFilterType.Consumable);
            if (_btnFilterMaterial != null) _btnFilterMaterial.clicked += () => ApplyFilterVisual(ItemFilterType.Material);

            VisualElement headerArea = _root.Q<VisualElement>("Header-Area");
            if (_inventoryWindow != null && headerArea != null)
            {
                _inventoryWindow.style.position = Position.Absolute;
                WindowDragManipulator dragManipulator = new WindowDragManipulator(_inventoryWindow, "MyInventoryPos");
                headerArea.AddManipulator(dragManipulator);
                dragManipulator.LoadPosition();
            }

            // 1. 공용 툴팁 뷰 조립
            if (_tooltipTemplate != null)
            {
                VisualElement tooltipInstance = _tooltipTemplate.Instantiate();
                _root.Add(tooltipInstance); 
                _tooltipView = new InventoryTooltipView(tooltipInstance[0]);
            }

            // 2. 버리기 확인창 포장지 분쇄 및 오버레이 부착
            if (_confirmationTemplate != null)
            {
                TemplateContainer container = _confirmationTemplate.Instantiate();
                VisualElement realBackdropRoot = container.childCount > 0 ? container[0] : null;

                if (realBackdropRoot != null)
                {
                    _root.Add(realBackdropRoot); 
                    _confirmationPopupView = new InventoryConfirmationPopupView(realBackdropRoot);
                }
            }

            // 3. [추가] 수량 분할 확인창 포장지 분쇄 및 오버레이 부착
            if (_splitTemplate != null)
            {
                TemplateContainer container = _splitTemplate.Instantiate();
                VisualElement realSplitRoot = container.childCount > 0 ? container[0] : null;

                if (realSplitRoot != null)
                {
                    _root.Add(realSplitRoot); 
                    _amountSplitPopupView = new InventoryAmountSplitPopupView(realSplitRoot);
                }
            }

            ApplyDynamicLayout();
            GenerateSlotsUI();
            ApplyFilterVisual(ItemFilterType.All);

            if (_inventoryWindow != null)
            {
                _inventoryWindow.style.display = DisplayStyle.None;
            }
        }

        private void ApplyFilterVisual(ItemFilterType filterType)
        {
            _viewModel.SetFilter(filterType);

            SetButtonNormalStyle(_btnFilterAll);
            SetButtonNormalStyle(_btnFilterEquip);
            SetButtonNormalStyle(_btnFilterConsume);
            SetButtonNormalStyle(_btnFilterMaterial);

            switch (filterType)
            {
                case ItemFilterType.All:
                    if (_btnFilterAll != null) _btnFilterAll.style.backgroundColor = BtnActiveBgColor;
                    break;

                case ItemFilterType.Equipment:  SetButtonActiveStyle(_btnFilterEquip); break;
                case ItemFilterType.Consumable: SetButtonActiveStyle(_btnFilterConsume); break;
                case ItemFilterType.Material:   SetButtonActiveStyle(_btnFilterMaterial); break;
            }
        }

        private void SetButtonNormalStyle(Button btn)
        {
            if (btn == null) return;
            btn.style.backgroundColor = BtnNormalBgColor;
            btn.style.color = TxtWhiteColor;
            btn.style.borderTopColor = Color.clear;
            btn.style.borderBottomColor = Color.clear;
            btn.style.borderLeftColor = Color.clear;
            btn.style.borderRightColor = Color.clear;
            btn.style.borderTopWidth = 1.5f;
            btn.style.borderBottomWidth = 1.5f;
            btn.style.borderLeftWidth = 1.5f;
            btn.style.borderRightWidth = 1.5f;
        }

        private void SetButtonActiveStyle(Button btn)
        {
            if (btn == null) return;
            btn.style.backgroundColor = BtnActiveBgColor;
            btn.style.color = TxtWhiteColor;
            btn.style.borderTopColor = HighlightBorderColor;
            btn.style.borderBottomColor = HighlightBorderColor;
            btn.style.borderLeftColor = HighlightBorderColor;
            btn.style.borderRightColor = HighlightBorderColor;
        }

        public void ToggleWindow()
        {
            if (_inventoryWindow == null) return;
            bool isVisible = _inventoryWindow.style.display == DisplayStyle.Flex;
            _inventoryWindow.style.display = isVisible ? DisplayStyle.None : DisplayStyle.Flex;
            
            if (!isVisible == false) CloseAllPopups();
        }

        public void CloseWindow()
        {
            if (_inventoryWindow != null)
            {
                _inventoryWindow.style.display = DisplayStyle.None;
                CloseAllPopups();
            }
        }

        // [추가] 열려있는 모든 팝업을 일괄 종료합니다.
        private void CloseAllPopups()
        {
            _tooltipView?.Hide();
            _confirmationPopupView?.Hide();
            _amountSplitPopupView?.Hide();
        }

        private void ApplyDynamicLayout()
        {
            if (_slotArea == null) return;

            float itemActualWidth = _slotSize + _slotHorizontalMargin;
            float requiredGridWidth = (itemActualWidth * _columnCount) + 1f;

            _slotArea.style.paddingLeft = _slotHorizontalMargin;
            float finalGridWidth = requiredGridWidth + _slotHorizontalMargin;
            _slotArea.style.width = finalGridWidth;

            _slotArea.style.flexShrink = 0;
            _slotArea.style.marginLeft = StyleKeyword.Auto;
            _slotArea.style.marginRight = StyleKeyword.Auto;

            _slotArea.style.justifyContent = Justify.FlexStart;
            _slotArea.style.flexDirection = FlexDirection.Row;
            _slotArea.style.flexWrap = Wrap.Wrap;
        }

        private void GenerateSlotsUI()
        {
            if (_slotArea == null || _slotTemplate == null) return;

            _slotArea.Clear();
            _slotViews.Clear();

            for (int i = 0; i < _viewModel.Capacity; i++)
            {
                VisualElement slotInstance = _slotTemplate.Instantiate();
                _slotArea.Add(slotInstance);

                VisualElement realSlotRoot = slotInstance[0];
                realSlotRoot.userData = i;
                realSlotRoot.pickingMode = PickingMode.Position;

                ItemSlotView slotView = new ItemSlotView(
                    realSlotRoot,
                    _root,
                    i,
                    (fromIdx, toIdx) => _viewModel.RequestSwapSlots(fromIdx, toIdx),
                    (index) => _viewModel.RequestUseItem(index),
                    (idx) => InterceptDeleteAction(idx)
                );

                slotView.OnPointerEnterSlot += (itemData, pos) => _tooltipView?.Show(itemData, pos);
                slotView.OnPointerMoveSlot += (pos) => _tooltipView?.UpdatePosition(pos);
                slotView.OnPointerExitSlot += () => _tooltipView?.Hide();

                // [추가] 조작기로부터 Shift+드래그 신호가 오면 분할 액션을 가로챕니다.
                slotView.OnSplitDropRequested += (fromIdx, toIdx) => InterceptSplitAction(fromIdx, toIdx);

                slotView.Bind(_viewModel.Slots[i]);
                _slotViews.Add(slotView);
            }
        }

        private void InterceptDeleteAction(int index)
        {
            if (_viewModel == null || index < 0 || index >= _viewModel.Slots.Count) return;

            var targetSlotVm = _viewModel.Slots[index];
            if (!targetSlotVm.HasItem || _confirmationPopupView == null) return;

            string cachedItemName = targetSlotVm.ItemData != null ? targetSlotVm.ItemData.Name : "알 수 없는 아이템";

            _confirmationPopupView.Show(targetSlotVm.ItemData, () =>
            {
                _viewModel.RequestRemoveItem(index);
                Debug.Log($"[PopupSystem] {cachedItemName} 버리기 처리가 최종 확정 승인되었습니다.");
            });
        }

        // [추가] Shift 분할 요청을 받아 팝업을 띄우고 ViewModel로 명령을 하달하는 메서드
        private void InterceptSplitAction(int fromIdx, int toIdx)
        {
            if (_viewModel == null) return;

            var srcSlotVm = _viewModel.Slots[fromIdx];
            var destSlotVm = _viewModel.Slots[toIdx];

            if (!srcSlotVm.HasItem || destSlotVm.HasItem || _amountSplitPopupView == null) return;

            if (int.TryParse(srcSlotVm.AmountText, out int totalAmount) == false) totalAmount = 1;
            if (totalAmount <= 1) return;

            _amountSplitPopupView.Show(srcSlotVm.ItemData, totalAmount, (splitAmount) =>
            {
                // UI에서 확인을 누르면 ViewModel의 분할 명령을 실제 호출합니다.
                _viewModel.RequestSeparateItem(fromIdx, toIdx, splitAmount);
            });
        }
    }
}