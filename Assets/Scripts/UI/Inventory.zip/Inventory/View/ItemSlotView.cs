using UnityEngine;
using UnityEngine.UIElements;
using System;

namespace MyInventory
{
    public class ItemSlotView
    {
        private readonly VisualElement _rootElement;
        private readonly VisualElement _iconElement;
        private readonly Label _countLabel;
        private readonly VisualElement _screenRoot; 
        private readonly int _index;                
        private readonly Action<int, int> _onDropRequest; 
        private readonly Action<int> _onUseRequest;
        private readonly Action<int> _onDeleteRequest;
        
        private readonly VisualElement _highlightElement;

        public event Action<ItemData, Vector2> OnPointerEnterSlot;
        public event Action<Vector2> OnPointerMoveSlot; 
        public event Action OnPointerExitSlot;
        
        // [누락 복구] Shift + 드래그 드롭 발생 시 뷰모델로 보내줄 중계 이벤트
        public event Action<int, int> OnSplitDropRequested;

        private float _lastClickTime;
        private const float DOUBLE_CLICK_THRESHOLD = 0.2f;
        private ItemSlotViewModel _viewModel;

        private static readonly Color HighlightBgColor = new Color(1f, 1f, 1f, 0.12f); 
        private static readonly Color HighlightBorderColor = new Color(1f, 0.84f, 0f, 1f); 

        public ItemSlotView(VisualElement slotVisualElement, VisualElement screenRoot, int index, 
                            Action<int, int> onDropRequest, Action<int> onUseRequest, Action<int> onDeleteRequest)
        {
            _rootElement = slotVisualElement;
            _screenRoot = screenRoot;
            _index = index;
            _onDropRequest = onDropRequest;
            _onDeleteRequest = onDeleteRequest;
            _onUseRequest = onUseRequest;
    
            _iconElement = _rootElement.Q<VisualElement>("Item-Icon");
            _countLabel = _rootElement.Q<Label>("Item-Count");
            _highlightElement = _rootElement.Q<VisualElement>("Item-Highlight");

            var dragManipulator = new ItemDragManipulator(_screenRoot, _index, () => _viewModel?.HasItem ?? false, _onDropRequest, _onDeleteRequest);
            
            // 조작기에서 올라온 분할 신호를 받아서 메인 뷰로 전달합니다.
            dragManipulator.OnSplitDropRequest += (fromIdx, toIdx) => OnSplitDropRequested?.Invoke(fromIdx, toIdx);
            
            _rootElement.AddManipulator(dragManipulator);

            _rootElement.RegisterCallback<PointerDownEvent>(OnPointerDown);
            _rootElement.RegisterCallback<PointerEnterEvent>(OnPointerEnter);
            _rootElement.RegisterCallback<PointerMoveEvent>(OnPointerMove);
            _rootElement.RegisterCallback<PointerLeaveEvent>(OnPointerLeave);
        }

        private void OnPointerEnter(PointerEnterEvent evt)
        {
            if (_viewModel != null && _viewModel.IsFilteredOut) return;

            if (_highlightElement != null)
            {
                _highlightElement.style.backgroundColor = HighlightBgColor;
                _highlightElement.style.borderTopColor = HighlightBorderColor;
                _highlightElement.style.borderBottomColor = HighlightBorderColor;
                _highlightElement.style.borderLeftColor = HighlightBorderColor;
                _highlightElement.style.borderRightColor = HighlightBorderColor;
                _highlightElement.style.borderTopWidth = 2f;
                _highlightElement.style.borderBottomWidth = 2f;
                _highlightElement.style.borderLeftWidth = 2f;
                _highlightElement.style.borderRightWidth = 2f;
            }

            if (_viewModel != null && _viewModel.HasItem)
            {
                OnPointerEnterSlot?.Invoke(_viewModel.ItemData, evt.position);
            }
        }

        private void OnPointerMove(PointerMoveEvent evt)
        {
            if (_viewModel != null && _viewModel.IsFilteredOut) return;
            if (_viewModel != null && _viewModel.HasItem)
            {
                OnPointerMoveSlot?.Invoke(evt.position);
            }
        }

        private void OnPointerLeave(PointerLeaveEvent evt)
        {
            ClearHighlightAndPopup();
        }

        private void ClearHighlightAndPopup()
        {
            if (_highlightElement != null)
            {
                _highlightElement.style.backgroundColor = StyleKeyword.Null;
                _highlightElement.style.borderTopColor = StyleKeyword.Null;
                _highlightElement.style.borderBottomColor = StyleKeyword.Null;
                _highlightElement.style.borderLeftColor = StyleKeyword.Null;
                _highlightElement.style.borderRightColor = StyleKeyword.Null;
                _highlightElement.style.borderTopWidth = StyleKeyword.Null;
                _highlightElement.style.borderBottomWidth = StyleKeyword.Null;
                _highlightElement.style.borderLeftWidth = StyleKeyword.Null;
                _highlightElement.style.borderRightWidth = StyleKeyword.Null;
            }
            OnPointerExitSlot?.Invoke();
        }

        public void Bind(ItemSlotViewModel viewModel)
        {
            _viewModel = viewModel;
            _viewModel.OnStateChanged += Render;
            Render();
        }

        private void Render()
        {
            if (_viewModel == null) return;

            if (_viewModel.IsFilteredOut)
            {
                ClearHighlightAndPopup();
            }

            if (_viewModel.HasItem)
            {
                if (_iconElement != null)
                {
                    _iconElement.style.backgroundImage = new StyleBackground(_viewModel.IconSprite);
                    _iconElement.style.unityBackgroundImageTintColor = _viewModel.IsFilteredOut 
                        ? new Color(0.25f, 0.25f, 0.25f, 1f) 
                        : Color.white;
                }
                
                if (_countLabel != null)
                {
                    if (_viewModel.IsAmountVisible)
                    {
                        _countLabel.style.display = DisplayStyle.Flex;
                        _countLabel.text = _viewModel.AmountText;
                    }
                    else
                    {
                        _countLabel.style.display = DisplayStyle.None;
                    }
                }
            }
            else
            {
                if (_iconElement != null)
                {
                    _iconElement.style.backgroundImage = null;
                    _iconElement.style.unityBackgroundImageTintColor = Color.white;
                }
                if (_countLabel != null) _countLabel.style.display = DisplayStyle.None;
            }
        }

        private void OnPointerDown(PointerDownEvent evt)
        {
            if (evt.button == 1) 
            {
                _onUseRequest?.Invoke(_index);
                evt.StopPropagation();
                return;
            }

            if (evt.button == 0)
            {
                float timeSinceLastClick = Time.time - _lastClickTime;
                if (timeSinceLastClick < DOUBLE_CLICK_THRESHOLD)
                {
                    _onUseRequest?.Invoke(_index);
                    _lastClickTime = 0;
                }
                else
                {
                    _lastClickTime = Time.time;
                }
            }
        }
    }
}