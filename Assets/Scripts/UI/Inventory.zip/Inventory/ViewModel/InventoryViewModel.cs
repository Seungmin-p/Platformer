using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using UnityEngine;

namespace MyInventory
{
    public enum ItemFilterType
    {
        All,
        Equipment,
        Consumable,
        Material
    }

    public class InventoryViewModel
    {
        private readonly Inventory _model;
        private readonly List<ItemSlotViewModel> _slots;

        public int Capacity => _model != null ? _model.Capacity : 0;
        public ReadOnlyCollection<ItemSlotViewModel> Slots { get; }
        
        public ItemFilterType CurrentFilter { get; private set; } = ItemFilterType.All;

        public InventoryViewModel(Inventory model)
        {
            _model = model;
            _slots = new List<ItemSlotViewModel>();

            if (_model == null)
            {
                Slots = _slots.AsReadOnly();
                return;
            }

            for (int i = 0; i < _model.Capacity; i++)
            {
                _slots.Add(new ItemSlotViewModel());
            }

            Slots = _slots.AsReadOnly();

            _model.OnSlotUpdated += RefreshSingleSlot;
            _model.OnAllSlotsUpdated += RefreshAllSlots;
            _model.OnCapacityChanged += HandleCapacityChanged;

            RefreshAllSlots();
        }

        public void SetFilter(ItemFilterType filterType)
        {
            if (CurrentFilter == filterType) return;
            CurrentFilter = filterType;
            RefreshAllSlots();
        }

        private bool IsFilteredOut(Item item)
        {
            if (item == null) return false;
            if (CurrentFilter == ItemFilterType.All) return false;
            
            if (CurrentFilter == ItemFilterType.Equipment && item is EquipmentItem) return false;
            if (CurrentFilter == ItemFilterType.Consumable && item is PotionItem) return false;
            if (CurrentFilter == ItemFilterType.Material && item is MaterialItem) return false;
            
            return true;
        }

        private void RefreshSingleSlot(int index)
        {
            if (index < 0 || index >= _slots.Count || _model == null) return;

            Item item = _model.GetItem(index); 

            if (item != null)
            {
                int amount = _model.GetCurrentAmount(index);
                bool isFilteredOut = IsFilteredOut(item); 
                
                _slots[index].UpdateSlot(item.Data, item.Data.IconSprite, amount, isFilteredOut);
            }
            else
            {
                _slots[index].ClearSlot();
            }
        }

        public void RefreshAllSlots()
        {
            if (_model == null) return;
            for (int i = 0; i < _slots.Count; i++)
            {
                if (i < _model.Capacity) RefreshSingleSlot(i);
                else _slots[i].ClearSlot();
            }
        }

        private void HandleCapacityChanged(int newCapacity) => RefreshAllSlots();

        public void CommandSort() { if (_model != null) _model.SortAll(); }
        public void CommandTrim() { if (_model != null) _model.TrimAll(); }
        public void RequestSwapSlots(int fromIdx, int toIdx) { if (_model != null) _model.Swap(fromIdx, toIdx); }
        public void RequestUseItem(int idx) { if (_model != null) _model.Use(idx); }
        public void RequestRemoveItem(int idx) { if (_model != null) _model.Remove(idx); }

        // [핵심 추가] 뷰에서 호출받아 모델의 수량 분할 메서드를 실행시키는 인터페이스
        public void RequestSeparateItem(int fromIdx, int toIdx, int amount)
        {
            if (_model != null)
            {
                _model.SeparateItem(fromIdx, toIdx, amount);
            }
        }
    }
}