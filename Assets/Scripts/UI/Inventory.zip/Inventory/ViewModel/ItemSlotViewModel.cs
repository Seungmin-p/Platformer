using System;
using UnityEngine;

namespace MyInventory
{
    public class ItemSlotViewModel
    {
        private ItemData _itemData;
        private Sprite _iconSprite;
        private int _amount;
        private bool _hasItem;
        private bool _isFilteredOut; // [추가] 필터링 제외 여부

        public event Action OnStateChanged;

        public bool HasItem => _hasItem;
        public Sprite IconSprite => _iconSprite;
        public ItemData ItemData => _itemData; 
        
        public bool IsAmountVisible => _hasItem && _amount > 1;
        public string AmountText => _amount.ToString();
        public bool IsFilteredOut => _isFilteredOut; // 외부 노출용

        // [수정] isFilteredOut 파라미터 추가
        public void UpdateSlot(ItemData itemData, Sprite icon, int amount, bool isFilteredOut)
        {
            if (_itemData == itemData && _iconSprite == icon && _amount == amount && 
                _hasItem == (icon != null) && _isFilteredOut == isFilteredOut) 
                return;

            _itemData = itemData;
            _iconSprite = icon;
            _amount = amount;
            _hasItem = icon != null && amount > 0;
            _isFilteredOut = isFilteredOut; // 상태 저장
            
            OnStateChanged?.Invoke();
        }

        public void ClearSlot()
        {
            if (!_hasItem && !_isFilteredOut) return;

            _itemData = null;
            _iconSprite = null;
            _amount = 0;
            _hasItem = false;
            _isFilteredOut = false; // 빈 슬롯은 필터링 상태 해제

            OnStateChanged?.Invoke();
        }
    }
}