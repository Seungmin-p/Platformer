using UnityEngine;
using UnityEngine.UIElements;

namespace MyInventory
{
    /// <summary>
    /// UI Toolkit 네이티브 PointerManipulator를 상속받아 구현한 커스텀 드래그 조작기입니다.
    /// 헤더 영역에 부착되어 가방 본체의 절대 좌표(Absolute Position)를 제어하고 위치를 로컬에 저장합니다.
    /// </summary>
    public class WindowDragManipulator : PointerManipulator
    {
        private readonly VisualElement _windowRoot;
        private readonly string _saveKey;
        
        private Vector2 _startPointerPosition;
        private Vector2 _startWindowPosition;
        private bool _isDragging;

        public WindowDragManipulator(VisualElement windowRoot, string saveKey = "InventoryWindowPos")
        {
            _windowRoot = windowRoot;
            _saveKey = saveKey;
            
            // 좌클릭 시에만 작동하도록 필터링
            activators.Add(new ManipulatorActivationFilter { button = MouseButton.LeftMouse });
        }

        // 타겟(헤더)에 마우스 이벤트 콜백 등록
        protected override void RegisterCallbacksOnTarget()
        {
            target.RegisterCallback<PointerDownEvent>(OnPointerDown);
            target.RegisterCallback<PointerMoveEvent>(OnPointerMove);
            target.RegisterCallback<PointerUpEvent>(OnPointerUp);
            target.RegisterCallback<PointerCaptureOutEvent>(OnPointerCaptureOut);
        }

        protected override void UnregisterCallbacksFromTarget()
        {
            target.UnregisterCallback<PointerDownEvent>(OnPointerDown);
            target.UnregisterCallback<PointerMoveEvent>(OnPointerMove);
            target.UnregisterCallback<PointerUpEvent>(OnPointerUp);
            target.UnregisterCallback<PointerCaptureOutEvent>(OnPointerCaptureOut);
        }

        private void OnPointerDown(PointerDownEvent evt)
        {
            if (_isDragging || !CanStartManipulation(evt)) return;

            _isDragging = true;
            _startPointerPosition = evt.position;
            // 현재 창의 좌표 획득
            _startWindowPosition = new Vector2(_windowRoot.layout.x, _windowRoot.layout.y);
            
            // 마우스 커서가 헤더를 벗어나도 이벤트를 놓치지 않도록 포인터 캡처
            target.CapturePointer(evt.pointerId);
            evt.StopPropagation();
        }

        private void OnPointerMove(PointerMoveEvent evt)
        {
            if (!_isDragging || !target.HasPointerCapture(evt.pointerId)) return;

            // 마우스 이동량(Delta) 계산 및 창 위치 갱신
            Vector2 delta = (Vector2)evt.position - _startPointerPosition;
            
            _windowRoot.style.left = _startWindowPosition.x + delta.x;
            _windowRoot.style.top = _startWindowPosition.y + delta.y;

            evt.StopPropagation();
        }

        private void OnPointerUp(PointerUpEvent evt)
        {
            if (!_isDragging || !target.HasPointerCapture(evt.pointerId)) return;

            _isDragging = false;
            target.ReleasePointer(evt.pointerId);
            evt.StopPropagation();

            // 드래그가 끝날 때 최종 좌표 저장
            SavePosition();
        }

        private void OnPointerCaptureOut(PointerCaptureOutEvent evt)
        {
            if (_isDragging)
            {
                _isDragging = false;
                SavePosition();
            }
        }

        // ==== 위치 세이브/로드 커스텀 로직 ====
        
        private void SavePosition()
        {
            // UI 상태 저장을 위해 가벼운 PlayerPrefs를 사용. 추후 JSON 데이터로 변경 가능합니다.
            PlayerPrefs.SetFloat(_saveKey + "_X", _windowRoot.resolvedStyle.left);
            PlayerPrefs.SetFloat(_saveKey + "_Y", _windowRoot.resolvedStyle.top);
            PlayerPrefs.Save();
        }

        public void LoadPosition()
        {
            // 저장된 위치 데이터가 있다면 덮어쓰기
            if (PlayerPrefs.HasKey(_saveKey + "_X") && PlayerPrefs.HasKey(_saveKey + "_Y"))
            {
                _windowRoot.style.left = PlayerPrefs.GetFloat(_saveKey + "_X");
                _windowRoot.style.top = PlayerPrefs.GetFloat(_saveKey + "_Y");
            }
        }
    }
}