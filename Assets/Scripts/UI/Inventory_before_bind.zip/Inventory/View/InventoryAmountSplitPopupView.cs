using UnityEngine;
using UnityEngine.UIElements;
using System;

namespace MyInventory
{
    public class InventoryAmountSplitPopupView : BasePopupView
    {
        private readonly Label _nameLabel;
        private readonly TextField _amountField;
        private readonly Button _btnPlus;
        private readonly Button _btnMinus;
        private readonly Button _btnConfirm;
        private readonly Button _btnCancel;

        //현재 개수, 현재 입력 가능한 최대 개수
        private int _currentAmount;
        private int _maxLimitAmount;
        private Action<int> _onConfirmCallback; //아이템 나누기 액션

        public InventoryAmountSplitPopupView(VisualElement rootElement) : base(rootElement)
        {
            _nameLabel = RootElement.Q<Label>("split-item-name");
            _amountField = RootElement.Q<TextField>("field-amount");
            _btnMinus = RootElement.Q<Button>("btn-minus");
            _btnPlus = RootElement.Q<Button>("btn-plus");
            _btnConfirm = RootElement.Q<Button>("btn-confirm");
            _btnCancel = RootElement.Q<Button>("btn-cancel");

            //마이너스, 플러스, 확인, 취소 버튼 이벤트 등록
            if (_btnMinus != null) _btnMinus.clicked += () => ApplyValueRange(_currentAmount - 1);
            if (_btnPlus != null) _btnPlus.clicked += () => ApplyValueRange(_currentAmount + 1);
            if (_btnConfirm != null) _btnConfirm.clicked += OnConfirmClicked;
            if (_btnCancel != null) _btnCancel.clicked += Hide;

            if (_amountField != null)
            {
                //수량 필드의 실제 텍스트 입력 영역을 가져옴
                VisualElement textInputZone = _amountField.Q("unity-text-input");
                if (textInputZone != null)
                {
                    //실제 텍스트 입력 영역의 텍스트 정렬을 중앙으로 지정
                    textInputZone.style.unityTextAlign = TextAnchor.MiddleCenter;
                }

                //입력 필드의 값(string)이 변경되는걸 감지해서 감지될 때 마다 OnTextFieldInputChanged 실행
                _amountField.RegisterCallback<ChangeEvent<string>>(OnTextFieldInputChanged);
            }
        }

        //팝업 내용 구성 후 출력
        public void Show(ItemData itemData, int currentSlotTotalAmount, Action<int> onConfirmAction)
        {
            if (itemData == null || currentSlotTotalAmount <= 1) return;

            _onConfirmCallback = onConfirmAction;
            if (_nameLabel != null) _nameLabel.text = itemData.Name;

            //아이템 이동이 아니라 나누기기 때문에 총 아이템 개수 -1
            _maxLimitAmount = currentSlotTotalAmount - 1;
            
            //아이템 나누기를 시도할 때 기본값은 아이템 개수의 절반으로 지정
            ApplyValueRange(currentSlotTotalAmount/2);

            //팝업 출력
            base.Show();
        }

        //수량 필드의 값 변경을 적용하는 메소드
        private void ApplyValueRange(int value)
        {
            //현재 입력된 개수를 1에서 최대 입력 가능 수치까지로 제한
            _currentAmount = Mathf.Clamp(value, 1, _maxLimitAmount);
            if (_amountField != null)
            {
                //SetValueWithoutNotify 즉, 이벤트 알림 없이 값을 변경해서, ApplyValueRange의 반복을 방지
                _amountField.SetValueWithoutNotify(_currentAmount.ToString());
            }
        }

        //_amountField의 값이 변경되었을 때 실행
        private void OnTextFieldInputChanged(ChangeEvent<string> evt)
        {
            //사용자가 입력한 텍스트(evt.newValue)를 int로 변환 시도 후, 성공 시 true
            if (int.TryParse(evt.newValue, out int parsedResult))
            {
                //전환 성공 시 전환된 숫자인 parsedResult를 가져와서 ApplyValueRange에 적용
                ApplyValueRange(parsedResult);
            }
            else
            {
                //int 전환 실패 시, 그냥 기존 값을 그대로 유지
                ApplyValueRange(_currentAmount);
            }
        }

        //확인 버튼 누를 시 
        private void OnConfirmClicked()
        {
            //우선 팝업을 닫아줌
            Hide();
            
            //콜백 저장 후 _onConfirmCallback은 다시 비워두기
            Action<int> callback = _onConfirmCallback;
            _onConfirmCallback = null;

            if (callback != null && _currentAmount > 0)
            {
                try
                {
                    //인벤토리 모델의 SeparateItem 메소드가 실행됨
                    callback.Invoke(_currentAmount);
                }
                catch (Exception ex)
                {
                    Debug.LogError($"[SplitPopup] 에러: {ex.Message}");
                }
            }
        }
    }
}