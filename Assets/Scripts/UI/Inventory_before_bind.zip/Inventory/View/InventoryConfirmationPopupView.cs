using UnityEngine;
using UnityEngine.UIElements;
using System;

namespace MyInventory
{
    //아이템 버리기 확인 팝업
    public class InventoryConfirmationPopupView : BasePopupView
    {
        private readonly Label _nameLabel;
        private readonly Button _btnConfirm;
        private readonly Button _btnCancel;
        private Action _onConfirmCallback; //아이템 버리기 액션

        public InventoryConfirmationPopupView(VisualElement rootElement) : base(rootElement)
        {
            _nameLabel = RootElement.Q<Label>("popup-item-name");
            _btnConfirm = RootElement.Q<Button>("btn-confirm");
            _btnCancel = RootElement.Q<Button>("btn-cancel");

            //확인 및 취소 버튼 이벤트 등록
            if (_btnConfirm != null) _btnConfirm.clicked += OnConfirmClicked;
            if (_btnCancel != null) _btnCancel.clicked += Hide;
        }

        //팝업 내용 구성 후 출력
        public void Show(ItemData itemData, Action onConfirmAction)
        {
            if (itemData == null) return;

            _onConfirmCallback = onConfirmAction;
            
            if (_nameLabel != null)
            {
                //아이템 이름 지정
                _nameLabel.text = itemData.Name;
            }

            //팝업 출력
            base.Show();
        }

        //버리기 확인 버튼 클릭 시 실행
        private void OnConfirmClicked()
        {
            //우선 팝업을 닫아줌
            Hide();

            //콜백 저장 후 _onConfirmCallback은 다시 비워두기
            Action callback = _onConfirmCallback;
            _onConfirmCallback = null; 

            //실제 삭제 처리 시도
            if (callback != null)
            {
                try
                {
                    //인벤토리 모델의 Remove 메소드가 실행됨
                    callback.Invoke();
                }
                catch (Exception ex)
                {
                    Debug.LogError($"[PopupSystem] 아이템 삭제 콜백 실행 중 백엔드 에러 발생: {ex.Message}");
                }
            }
        }
    }
}